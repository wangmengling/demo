//
//  UserModel.swift
//  demo
//
//  Created by apple on 16/4/22.
//  Copyright © 2016年 jackWang. All rights reserved.
//

import Foundation
struct UserModel{
    var Name: String!
    var PassWord: String!
}