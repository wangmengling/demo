//
//  Storage.swift
//  demo
//
//  Created by apple on 16/7/20.
//  Copyright © 2016年 jackWang. All rights reserved.
//

import Foundation
struct Storage<Element:DataConversionProtocol> {
//    private static let sharedInstance = Storage()
    internal typealias E = Element
//    private lazy var srorageToSQLite = SrorageToSQLite()
    init(){
//        srorageToSQLite = SrorageToSQLite()
    }
}

extension Storage {
    func objects<E>() -> Array<E>? {
        return nil
    }
    
    func add(object:E) {
        guard let object:E = object else {
            return
        }
        
        if !SrorageToSQLite().tableIsExists(object){
            SrorageToSQLite().createTable(object)
        }
        SrorageToSQLite().insert(object)
        return
    }
    
    mutating func addArray(objectArray:[E]?) {
//        objectArray.map {
////            self.add($0)
//        }
    }
}