//
//  StoreModel.swift
//  demo
//
//  Created by jackWang on 16/4/23.
//  Copyright © 2016年 jackWang. All rights reserved.
//

import Foundation

class StoreModel {
    var name:String!
    var address:String!
}