//
//  CounterViewController.swift
//  demo
//
//  Created by apple on 16/5/13.
//  Copyright © 2016年 jackWang. All rights reserved.
//

import UIKit
import ReSwift

class CounterViewController: UIViewController {
    @IBOutlet var counterLabel: UILabel!


}
