//
//  Stores.swift
//  demo
//
//  Created by jackWang on 16/5/15.
//  Copyright © 2016年 jackWang. All rights reserved.
//

import Foundation
